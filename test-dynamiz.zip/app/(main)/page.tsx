'use client'
import { title } from "@/components/primitives";
import {Cardlist} from '../../components/ui/card-list';
import TableView from '../../components/ui/table-view';
// import {SuperTable} from '../../components/ui/SuperTable';

// data
import { MainProject } from "@/data/tableProject";



export default function Main() {
  return (
    <div className="flex flex-col grow">
      <h1 className={title({ size: "sm", class: "mt-2"})}>Dashboard</h1>
      <header className="h-42 mt-5">
      <Cardlist/>
      </header>
      <main className="mt-10">
        <TableView/>
      </main>
      {/* <SuperTable/> */}
    </div>
  );
}
