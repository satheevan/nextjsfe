'use client'
import { Card, CardBody } from "@nextui-org/react";
import Model from "@/components/ui/model";
import { useRouter } from "next/router";

const cardItems = [
  {
    label:"Test 98",
    count:"2",
    date:"August 9, 2024"
  },
  {
    label:"Test 556",
    count:"7",
    date:"September 9, 2024"
  },
  {
    label:"Test 398",
    count:"0",
    date:"August 9, 2024"
  },
  {
    label:"Test 948",
    count:"2",
    date:"August 9, 2024"
  },
  {
    label:"Test 29",
    count:"2",
    date:"August 9, 2024"
  }
  
];
const DraftItems = [
  {
    label:"Test 18",
    count:"2",
    date:"August 9, 2024"
  },
  {
    label:"Test 56",
    count:"7",
    date:"September 9, 2024"
  },
]
const router = useRouter
export default function TestSuites() {
  return (
    <section className="flex flex-col grow md:py-3">
      <div className="flex justify-end flex-wrap mr-3">
        <Model/>
      </div>
      <h1 className="text-4xl font-bold">Existing Test Suites</h1>
      <div className="my-3 grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {cardItems?.map((val,index)=>(  
          <div>      
          <Card>
            <CardBody>
              <div className="p-3 py-7">
              <div className="mb-2">
                <span className="text-xl font-bold">{val.label}</span>
                <span className="ml-2">{`(${val.count})`}</span>
                </div>
              <div>{val.date}</div>
              </div>
            </CardBody>
        </Card>
        </div>
      ))}
        </div>
      <h1 className="text-4xl font-bold">Draft Test</h1>
      <div className="my-3 grid grid-cols-1 gap-5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {DraftItems?.map((val,index)=>(  
          <div>      
          <Card>
            <CardBody>
              <div className="p-3 py-7">
              <div className="mb-6">
                <span className="text-xl font-bold">{val.label}</span>
                <span className="ml-2">{`(${val.count})`}</span>
                </div>
              <div>{val.date}</div>
              </div>
            </CardBody>
        </Card>
        </div>
      ))}
        </div>
    </section>
  );
}
