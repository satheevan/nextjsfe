'use client'
// import { Card, CardBody } from "@nextui-org/react";

import Model from "@/components/ui/model";
import TableView from "@/components/ui/table-view";

export default function TestSuits() {
  return (
    <section className="flex flex-col grow md:py-3">
      <div className="flex justify-end mr-4">
        <Model/>
        </div>
      <h1 className="text-4xl font-bold my-3">Existing Test Suites</h1>
      <TableView/>
      
    </section>
  );
}
