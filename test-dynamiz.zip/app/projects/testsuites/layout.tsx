'use client'
import LeftSideNav from "@/components/ui/left-navbar";

export default function TestSuites({
    children,
  }: {
    children: React.ReactNode;
  }) {
    return (
      <section className="flex grow gap-1 py-8 md:py-0">
        <LeftSideNav/>
        <div className="flex grow">
          {children}
        </div>
      </section>
    );
  }
  