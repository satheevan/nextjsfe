'use client'
// import { Card, CardBody } from "@nextui-org/react";

import TabView from "@/components/ui/tab";


export default function TestDux() {
  return (
    <section className="flex flex-col grow md:py-3">
      <h1 className="text-4xl font-bold my-3">DUX</h1>
      <TabView/>
    </section>
  );
}
