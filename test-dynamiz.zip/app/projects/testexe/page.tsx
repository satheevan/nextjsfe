// 'use client'
// import { Card, CardBody } from "@nextui-org/react";

import TableView from "@/components/ui/table-view";

export default function TestExe() {
  return (
    <section className="flex flex-col grow md:py-3">
      <h1 className="text-4xl font-bold mb-3">Test Execution</h1>
      {/* <SelectTable/> */}
      <TableView/>
      <h1 className="text-4xl font-bold my-3">Trends</h1>
    </section>
  );
}
