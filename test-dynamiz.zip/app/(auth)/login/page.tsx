import { title } from "@/components/primitives";
// import {SuperTable} from '../../components/ui/SuperTable';

// data

export default function Login() {
  return (
    <div className="flex flex-col grow">
      <h1 className={title({ size: "sm", class: "mt-2 text-center"})}>Login</h1>
      <header className="h-42 mt-5 text-center">
        Starting to New life
      </header>
      <main className="mt-10 flex flex-col gap-2 justify-center items-center ">
        <div className="bg-[#ddd9d9] flex flex-col rounded-lg gap-3 p-8">
        <input type="text" placeholder="Username" className="p-2 rounded-md"/>
        <br></br>
        <input type="password" placeholder="Password" className="p-2 rounded-md"/>
        </div>
        <br></br>
        <button type="button" className="bg-[#828282] rounded-lg p-2 hover:bg-[#616060]">Submit</button>
      </main>
      {/* <SuperTable/> */}
    </div>
  );
}
