import { useState } from 'react';
import { Input, Dropdown, } from '@nextui-org/react';
import Fuse from 'fuse.js';

import {Projects} from '../data/default'

const Autocompletion =({options=[],placeholder="Select...",onSelect=()=>{},ClassName="",...props})=>{
  
  const [query,setQuery] =useState('')
  const [filteredItems,setFilteredItems] = useState([]);

  const fuse = new Fuse(options,{keys:['label']})

  const handleInputChange =(e)=>{
      const value = e.target.value
      
      const results = value ? fuse.search(value).map((result)=>result.item):[];
      setFilteredItems(results)
  }
  
  const handleSelect =(item)=>{
      setQuery(item.label);
      setFilteredItems([]);
      if(onSelect){
        onSelect(item);
      }
  };
    // const filteritems = options.filter((val)=>val)

    return(
        <div className={`flex w-full flex-wrap md:flex-nowrap gap-4 ${ClassName}`}>
          <Input
            placeholder={placeholder}
            value={query}
            onChange={handleInputChange}
            isClearable
            aria-label='Autocomplete input'
          />
          {/* {filteredItems.length>0&&(
            <Dropdown>
              {filteredItems.map((item)=>(
                <Dropdown. key></Dropdown>
              ))}
            </Dropdown>
          )} */}
          {filteredItems.length > 0 && (
        <Dropdown>
          {filteredItems.map((item) => (
            <Dropdown.Item key={item.id} onClick={() => handleSelect(item)}>
              {item.label}
            </Dropdown.Item>
          ))}
        </Dropdown>
      )}

        </div>
    )
}
export default Autocompletion;