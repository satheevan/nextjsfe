import { Listbox, ListboxItem } from "@nextui-org/react";
import { DashboardIcon } from "../icons/dashboard";
import { TasksIcon } from "../icons/tasks";
import { FormsIcon } from "../icons/forms";

function LeftSideNav() {
  return (
    <div className="hidden sm:block w-52 pt-2 ">
      <Listbox aria-label="Navigation menu">
        <ListboxItem key="dashboard" href="/projects/dashboard">
          <div className="flex items-center gap-2">
            <DashboardIcon /> DashBoard
          </div>
        </ListboxItem>
        <ListboxItem key="suits" href="/projects/testsuites">
          <div className="flex items-center gap-2">
          <TasksIcon /> Test Suites
          </div>
        </ListboxItem>
        <ListboxItem key="execution" href="/projects/testexe">
          <div className="flex items-center gap-2">
          <FormsIcon /> Test Exec
          </div>
        </ListboxItem>
        <ListboxItem key="dux" href="/projects/dux">
          DUX
        </ListboxItem>
        <ListboxItem key="synthetic" href="/projects/synthetic">
          Synthetic
        </ListboxItem>
      </Listbox>
    </div>
  );
}
export default LeftSideNav;