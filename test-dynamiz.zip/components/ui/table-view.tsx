"use client"

import {Table, TableHeader, TableColumn, TableBody, TableRow, TableCell, getKeyValue} from "@nextui-org/react";

const rows = [
  {
    key: "1",
    projects: "Inventory",
    totaltests: "500",
    totalsuits:"25",
    action: "Edit",
  },
  {
    key: "2",
    projects: "Cart",
    totaltests: "700",
    totalsuits:"5",
    action: 'Edit',
  },
  {
    key: "3",
    projects: "Stocks",
    totaltests: "700",
    totalsuits:"5",
    action: 'Edit',
  },
  {
    key: "4",
    projects: "CRM",
    totaltests: "700",
    totalsuits:"5",
    action: 'Edit',
  },
];

const columns = [
  {
    key: "projects",
    label: "Projects",
  },
  {
    key: "totaltests",
    label: "Total Tests",
  },
  {
    key: "totalsuits",
    label: "Total Suits",
  },
  {
      key: "action",
      label: "Edit",
  },
];

// function TableView({columns=[],rows=[],...props}) {
function TableView() {
  return (
    <Table aria-label="Example table with dynamic content">
      <TableHeader columns={columns}>
        {(column) => <TableColumn key={column.key}>{column.label}</TableColumn>}
      </TableHeader>
      <TableBody items={rows} className="" >
        {(item) => (
          <TableRow key={item.key} className="" >
            {(columnKey) => <TableCell className="" >{getKeyValue(item, columnKey)}</TableCell>}
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
}

export default TableView;