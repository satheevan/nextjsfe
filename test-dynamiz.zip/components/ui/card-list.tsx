"use client";
import { Card, CardBody } from "@nextui-org/react";
import React from "react";

export const Cardlist = () => {
  return (
    <Card>
      <CardBody>
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4 xl:gap-0">
          <div className="flex items-center justify-center gap-2 border-b border-stroke pb-5 last:border-b-0 last:pb-0 dark:border-dark-3 xl:border-b-0 xl:border-r xl:pb-0 last:xl:border-r-0">
            <div className="">
              <div className="flex items-center gap-4.5">
                <h4 className="text-xl font-bold text-dark dark:text-white md:text-heading-5 mb-4">
                  25
                </h4>
              </div>
              <p className="-mt-1 text-body-sm font-medium">Total Projects</p>
            </div>
          </div>
          <div className="flex items-center justify-center gap-2 border-b border-stroke pb-5 last:border-b-0 last:pb-0 dark:border-dark-3 xl:border-b-0 xl:border-r xl:pb-0 last:xl:border-r-0">
            <div className="p-4">
              <div className="flex items-center gap-4.5">
                <h4 className="text-xl font-bold text-dark dark:text-white md:text-heading-5 mb-4">
                  2500
                </h4>
              </div>
              <p className="mt-1 text-body-sm font-medium">Total </p>
            </div>
          </div>
          <div className="flex items-center justify-center gap-2 border-b border-stroke pb-5 last:border-b-0 last:pb-0 dark:border-dark-3 xl:border-b-0 xl:border-r xl:pb-0 last:xl:border-r-0">
            <div className="p-4">
              <div className="flex items-center gap-4.5">
                <h4 className="text-xl font-bold text-dark dark:text-white md:text-heading-5 mb-4">
                  75
                </h4>
              </div>
              <p className="-mt-1 text-body-sm font-medium">Total Projects</p>
            </div>
          </div>
          <div className="flex items-center justify-center gap-2 border-b border-stroke pb-5 last:border-b-0 last:pb-0 dark:border-dark-3 xl:border-b-0 xl:border-r xl:pb-0 last:xl:border-r-0">
            <div className="p-4">
              <div className="flex items-center gap-4.5">
                <h4 className="text-xl font-bold text-dark dark:text-white md:text-heading-5 mb-4">
                  25
                </h4>
              </div>
              <p className="-mt-1 text-body-sm font-medium">Total Projects</p>
            </div>
          </div>
          
        </div>
      </CardBody>
    </Card>
  );
  // return (
  //   <div className="card-container flex-grow mt-10">
  //       <div className="card p-0 flex grow h-34 text-center">
  //         <div className="p-5 md:border-r-2 basis-1/4">
  //           <div className="flex flex-col gap-5">
  //             <strong className="text-large">Total Sales</strong>
  //             <strong className="">25</strong>
  //           </div>
  //         </div>
  //         <div className="p-5 md:border-r-2 basis-1/4">
  //         <div className="flex flex-col gap-5">
  //             <strong className="text-large">Total Tests</strong>
  //             <strong className="">2500</strong>
  //           </div>
  //           </div>
  //         <div className="p-5 md:border-r-2 basis-1/4">
  //         <div className="flex flex-col gap-5">
  //             <strong className="text-large">Total Suits</strong>
  //             <strong className="">75</strong>
  //           </div>
  //         </div>
  //         <div className="p-5 md:basis-1/4">
  //         <div className="flex flex-col gap-5">
  //             <strong className="text-large">Schedule Jobs</strong>
  //             <strong className="">30</strong>
  //           </div>
  //         </div>
  //       </div>
  //     </div>
  // )
};
