import React from "react";



export default function PageTable({ data }: { data: { count: number, results: []}},{column}:{column:[{label:"",key:""}]}) {
  const [page, setPage] = React.useState(1);
  const [columnData,setColumnData] = React.useState([])
  const rowsPerPage = 10;

  const pages = React.useMemo(() => {
    return data?.count ? Math.ceil(data.count / rowsPerPage) : 0;
  }, [data?.count, rowsPerPage]);



  return (
    <div>
      <table className="table-fixed">
  <thead>
    <tr>
      {column?.map((val,index)=>(
        <th key={index}>{val.label}</th>
      ))
      }
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>The Sliding Mr. Bones (Next Stop, Pottersville)</td>
      <td>Malcolm Lockyer</td>
      <td>1961</td>
    </tr>
    <tr>
      <td>Witchy Woman</td>
      <td>The Eagles</td>
      <td>1972</td>
    </tr>
    <tr>
      <td>Shining Star</td>
      <td>Earth, Wind, and Fire</td>
      <td>1975</td>
    </tr>
  </tbody>
</table>
    </div>
  );
}
